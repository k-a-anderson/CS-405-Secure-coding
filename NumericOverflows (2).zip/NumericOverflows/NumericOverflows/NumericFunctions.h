#pragma once

#include <limits>

// Addition function
template <typename T>
bool add_numbers(T const& start, T const& increment,
    unsigned long int const& steps, T& result)
{
    // Store starting value in result
    result = start;

    for (unsigned long int i = 0; i < steps; ++i)
    {
        // Check for overflow before adding
        if (result > std::numeric_limits<T>::max() - increment)
        {
            return false; // Overflow detected
        }
        else
        {
            result += increment;
        }
    }

    return true; // Calculation completed safely
}


// Subtraction function
template <typename T>
bool subtract_numbers(T const& start, T const& decrement,
    unsigned long int const& steps, T& result)
{
    // Store starting value in result
    result = start;

    for (unsigned long int i = 0; i < steps; ++i)
    {
        // Check for underflow before subtracting
        if (result < decrement)
        {
            return false; // Underflow detected
        }
        else
        {
            result -= decrement;
        }
    }

    return true; // Calculation completed safely
}
