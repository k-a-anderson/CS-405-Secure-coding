#include "pch.h"
#include "CppUnitTest.h"
#include "../NumericOverflows/NumericFunctions.h"

using namespace Microsoft::VisualStudio::CppUnitTestFramework;

namespace NumericOverflowTests
{
	TEST_CLASS(NumericOverflowTests)
	{
	public:
		
		TEST_METHOD(TestNormalAddition)
		{
			int result = 0;

			bool success = add_numbers<int>(10, 20, 1, result);

			Assert::IsTrue(success);
			Assert::AreEqual(30, result);
		}

		TEST_METHOD(TestAdditionOverflow)
		{
			int result = 0;

			bool success = add_numbers<int>(
				std::numeric_limits<int>::max(), 1, 1, result);

			Assert::IsFalse(success);
		}

		TEST_METHOD(TestNormalSubtraction)
		{
			int result = 0;

			bool success = subtract_numbers<int>(50, 20, 1, result);

			Assert::IsTrue(success);
			Assert::AreEqual(30, result);
		}

		TEST_METHOD(TestSubtractionUnderflow)
		{
			unsigned int result = 0;

			bool success = subtract_numbers<unsigned int>(
				0u, 1u, 1, result);

			Assert::IsFalse(success);
		}
	};
}
